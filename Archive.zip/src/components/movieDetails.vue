<template>
     <div>
         <h1>Movie details</h1>


     </div>
</template>

<script>
export default {

  data: function(){
    return {
      loading: false,
      movie_details: ''
    }
  },


  // Functions
  methods: {

    fetchData() {

      this.loading = true;

      this.$http.get('https://api.themoviedb.org/3/movie/284052?language=en-US&api_key=37f0eca988a8498c779fac93ab4c4189')

        .then(response => {
          //  return response.json();

          this.movie_details = response.body.results
          this.loading = false;
         console.log(movie_details);

        }, error => {
          console.log();
        });
    },


  },




  // Load data on page load
  mounted: function() {
    this.fetchData();
  }

}
</script>
